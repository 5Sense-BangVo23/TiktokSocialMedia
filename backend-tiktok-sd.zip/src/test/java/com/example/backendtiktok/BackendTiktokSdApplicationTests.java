package com.example.backendtiktok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendTiktokSdApplicationTests {

	@Test
	void contextLoads() {
	}

}
